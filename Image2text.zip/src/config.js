// 配置文件
// 请在此处设置您的 DeepSeek API Key
export default {
  apiKey: 'sk-8ba3210a85f1424f916927b7af2150da' // 请在此处填写您的 DeepSeek API Key
};
